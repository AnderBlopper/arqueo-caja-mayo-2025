import React from 'react';
import { jsPDF } from 'jspdf';

const PDFButton = ({ coinsCount, total, responsable }) => {
  const generatePDF = () => {
    const doc = new jsPDF();
    
    doc.setFontSize(18);
    doc.text('Reporte de Arqueo de Caja', 105, 20, { align: 'center' });
    
    doc.setFontSize(12);
    doc.text(`Responsable: ${responsable}`, 20, 40);
    doc.text(`Fecha: ${new Date().toLocaleDateString()}`, 20, 50);
    
    doc.setFontSize(14);
    doc.text('Detalle de Monedas:', 20, 70);
    
    let yPosition = 80;
    Object.keys(coinsCount).forEach((value) => {
      const coin = coins.find(c => c.value === parseFloat(value));
      if (coin && coinsCount[value] > 0) {
        doc.text(`${coin.label}: ${coinsCount[value]} = S/. ${(coin.value * coinsCount[value]).toFixed(2)}`, 20, yPosition);
        yPosition += 10;
      }
    });
    
    doc.setFontSize(16);
    doc.text(`Total General: S/. ${total.toFixed(2)}`, 20, yPosition + 20);
    
    doc.save(`Arqueo_${responsable.replace(' ', '_')}_${new Date().toISOString().slice(0,10)}.pdf`);
  };

  return (
    <button
      onClick={generatePDF}
      className="w-full mt-4 py-2 px-4 bg-green-600 hover:bg-green-700 text-white font-medium rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-colors"
    >
      Generar PDF
    </button>
  );
};

export default PDFButton;
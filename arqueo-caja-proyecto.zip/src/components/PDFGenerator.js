import React from 'react';

const PDFGenerator = ({ coins, coinsCount, total, responsable, date }) => {
  const generatePDF = () => {
    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Arqueo de Caja UPeU</title>
        <style>
          @page { size: A4; margin: 2cm; }
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; color: #333; }
          .header { text-align: center; margin-bottom: 1.5cm; }
          .logo { font-size: 16pt; color: #003366; font-weight: bold; }
          .title { font-size: 14pt; margin-top: 10pt; color: #003366; }
          .subtitle { font-size: 12pt; color: #555; margin-top: 5pt; }
          .info-container { display: flex; justify-content: space-between; margin-bottom: 1cm; }
          .info-box { width: 48%; }
          .info-label { font-weight: bold; color: #003366; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 1cm; }
          th { background: #003366; color: white; padding: 8pt; text-align: left; font-weight: bold; }
          td { padding: 8pt; border-bottom: 1pt solid #ddd; }
          .denomination { font-weight: bold; }
          .total-row { font-weight: bold; background: #f5f5f5; }
          .signature-container { display: flex; justify-content: space-between; margin-top: 1.5cm; }
          .signature-box { width: 30%; text-align: center; }
          .signature-line { border-top: 1pt solid #000; width: 80%; margin: 20pt auto 5pt; }
          .signature-title { font-size: 10pt; }
          .footer { margin-top: 1cm; font-size: 9pt; text-align: center; color: #777; }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="logo">UNIVERSIDAD PERUANA UNIÓN</div>
          <div class="title">ARQUEO DE CAJA</div>
          <div class="subtitle">Sistema de Control de Efectivo</div>
        </div>
        
        <div class="info-container">
          <div class="info-box">
            <span class="info-label">Responsable:</span> ${responsable}
          </div>
          <div class="info-box">
            <span class="info-label">Fecha:</span> ${new Date(date).toLocaleDateString('es-PE', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </div>
        </div>
        
        <table>
          <thead>
            <tr>
              <th>Denominación</th>
              <th>Cantidad</th>
              <th>Subtotal (S/.)</th>
            </tr>
          </thead>
          <tbody>
            ${Object.keys(coinsCount)
              .filter(value => coinsCount[value] !== '')
              .map(value => {
                const coin = coins.find(c => c.value === parseFloat(value));
                return `
                  <tr>
                    <td class="denomination">${coin.label}</td>
                    <td>${coinsCount[value]}</td>
                    <td>${(coin.value * coinsCount[value]).toFixed(2)}</td>
                  </tr>
                `;
              }).join('')}
            <tr class="total-row">
              <td colspan="2">TOTAL GENERAL</td>
              <td>S/. ${total.toFixed(2)}</td>
            </tr>
          </tbody>
        </table>
        
        <div class="signature-container">
          <div class="signature-box">
            <div class="signature-line"></div>
            <div class="signature-title">Responsable del Arqueo</div>
          </div>
          <div class="signature-box">
            <div class="signature-line"></div>
            <div class="signature-title">Verificador</div>
          </div>
          <div class="signature-box">
            <div class="signature-line"></div>
            <div class="signature-title">Administrador</div>
          </div>
        </div>
        
        <div class="footer">
          Documento generado automáticamente por el Sistema de Arqueo de Caja UPeU
        </div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    printWindow.document.write(htmlContent);
    printWindow.document.close();
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
    }, 300);
  };

  return (
    <button
      onClick={generatePDF}
      className="w-full mt-6 py-3 px-6 bg-gradient-to-r from-blue-600 to-blue-800 text-white font-bold rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-[1.02] focus:outline-none focus:ring-4 focus:ring-blue-300"
    >
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 inline mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
      </svg>
      Generar Reporte PDF
    </button>
  );
};

export default PDFGenerator;
import React, { useState } from 'react';

const CoinInput = ({ coin, onCountChange }) => {
  const [count, setCount] = useState('');
  const [isValid, setIsValid] = useState(true);

  const handleChange = (e) => {
    const value = e.target.value;
    const isValidInput = value === '' || (!isNaN(value) && parseInt(value) >= 0);
    
    setCount(value);
    setIsValid(isValidInput);
    
    if (isValidInput) {
      const newCount = value === '' ? '' : parseInt(value) || 0;
      onCountChange(coin.value, newCount);
    }
  };

  return (
    <div className={`${coin.bgColor} ${coin.borderColor} border-l-4 p-4 rounded-lg shadow-sm mb-3 transition-all duration-200 hover:shadow-md`}>
      <div className="flex items-center justify-between">
        <span className="font-semibold text-gray-800">{coin.label}</span>
        <div className="flex items-center space-x-3">
          <input
            type="text"
            inputMode="numeric"
            value={count}
            onChange={handleChange}
            className={`w-24 px-3 py-2 border ${isValid ? 'border-gray-300' : 'border-red-500'} rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-right`}
            placeholder="0"
          />
          <span className="w-24 text-right font-medium text-gray-700">
            = S/. {(coin.value * (count || 0)).toFixed(2)}
          </span>
        </div>
      </div>
      {!isValid && <p className="text-red-500 text-xs mt-1">Ingrese un número válido</p>}
    </div>
  );
};

export default CoinInput;
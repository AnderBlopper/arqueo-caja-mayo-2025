import React from 'react';

const TotalDisplay = ({ total }) => {
  return (
    <div className="mt-6 p-4 bg-blue-50 rounded-lg">
      <h3 className="text-lg font-semibold text-gray-800">Total General:</h3>
      <p className="text-2xl font-bold text-blue-600">S/. {total.toFixed(2)}</p>
    </div>
  );
};

export default TotalDisplay;
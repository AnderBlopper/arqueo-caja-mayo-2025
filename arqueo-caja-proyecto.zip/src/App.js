import React, { useState, useEffect } from 'react';
import coins from './mock/coins';
import CoinInput from './components/CoinInput';
import ResponsableInput from './components/ResponsableInput';
import DatePicker from './components/DatePicker';
import TotalDisplay from './components/TotalDisplay';
import PDFGenerator from './components/PDFGenerator';

const App = () => {
  const [coinsCount, setCoinsCount] = useState({});
  const [total, setTotal] = useState(0);
  const [responsable, setResponsable] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);

  useEffect(() => {
    const initialCounts = {};
    coins.forEach(coin => {
      initialCounts[coin.value] = '';
    });
    setCoinsCount(initialCounts);
  }, []);

  const handleCountChange = (value, count) => {
    setCoinsCount(prev => ({
      ...prev,
      [value]: count === '' ? '' : parseInt(count) || 0
    }));
  };

  useEffect(() => {
    const newTotal = coins.reduce((sum, coin) => {
      return sum + (coin.value * (coinsCount[coin.value] || 0));
    }, 0);
    setTotal(newTotal);
  }, [coinsCount]);

  const handleNameChange = (name) => {
    setResponsable(name);
  };

  const handleDateChange = (newDate) => {
    setDate(newDate);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <div className="bg-white rounded-xl shadow-xl overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-800 to-blue-600 p-6 text-white">
            <h1 className="text-2xl sm:text-3xl font-bold text-center">Arqueo de Caja UPeU</h1>
            <p className="text-center text-blue-100 mt-2">Sistema de Control de Efectivo</p>
          </div>
          
          {/* Formulario */}
          <div className="p-6 sm:p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <ResponsableInput onNameChange={handleNameChange} />
              <DatePicker date={date} onDateChange={handleDateChange} />
            </div>
            
            <div className="mb-8">
              <h2 className="text-lg font-semibold text-gray-800 mb-4">Ingrese las cantidades:</h2>
              <div className="space-y-3">
                {coins.map(coin => (
                  <CoinInput 
                    key={coin.value} 
                    coin={coin} 
                    onCountChange={handleCountChange} 
                  />
                ))}
              </div>
            </div>
            
            <TotalDisplay total={total} />
            
            <div className="mt-8">
              <PDFGenerator 
                coins={coins}
                coinsCount={coinsCount} 
                total={total} 
                responsable={responsable}
                date={date}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;

// DONE
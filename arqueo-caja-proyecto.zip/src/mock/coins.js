const coins = [
  { value: 0.10, label: 'S/ 0.10', bgColor: 'bg-blue-50', borderColor: 'border-blue-200' },
  { value: 0.20, label: 'S/ 0.20', bgColor: 'bg-blue-100', borderColor: 'border-blue-300' },
  { value: 0.50, label: 'S/ 0.50', bgColor: 'bg-blue-200', borderColor: 'border-blue-400' },
  { value: 1, label: 'S/ 1.00', bgColor: 'bg-green-50', borderColor: 'border-green-200' },
  { value: 2, label: 'S/ 2.00', bgColor: 'bg-green-100', borderColor: 'border-green-300' },
  { value: 5, label: 'S/ 5.00', bgColor: 'bg-green-200', borderColor: 'border-green-400' },
  { value: 10, label: 'S/ 10.00', bgColor: 'bg-yellow-50', borderColor: 'border-yellow-200' },
  { value: 20, label: 'S/ 20.00', bgColor: 'bg-yellow-100', borderColor: 'border-yellow-300' },
  { value: 50, label: 'S/ 50.00', bgColor: 'bg-yellow-200', borderColor: 'border-yellow-400' },
  { value: 100, label: 'S/ 100.00', bgColor: 'bg-red-50', borderColor: 'border-red-200' },
  { value: 200, label: 'S/ 200.00', bgColor: 'bg-red-100', borderColor: 'border-red-300' }
];

export default coins;